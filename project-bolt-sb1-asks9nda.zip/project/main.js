// Reflexion AI Creative Generation System
class ReflexionApp {
  constructor() {
    this.baseImage = null;
    this.selectedPlatforms = ['facebook', 'instagram', 'tiktok'];
    this.selectedFormats = ['post', 'story'];
    this.brandData = null;
    this.blogData = null;
    this.demographics = {
      age: '25-34',
      gender: 'all',
      interests: [],
      location: 'global'
    };
    this.objective = 'awareness';
    this.generatedCreatives = [];
    
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.updateSelectedOptions();
    this.initializeTabs();
    this.initializeInterestTags();
  }

  setupEventListeners() {
    // Image upload
    const uploadArea = document.getElementById('uploadArea');
    const imageInput = document.getElementById('imageInput');
    const removeBtn = document.getElementById('removeImage');

    uploadArea.addEventListener('click', () => imageInput.click());
    uploadArea.addEventListener('dragover', this.handleDragOver.bind(this));
    uploadArea.addEventListener('drop', this.handleDrop.bind(this));
    imageInput.addEventListener('change', this.handleImageSelect.bind(this));
    removeBtn.addEventListener('click', this.removeImage.bind(this));

    // Platform selection
    document.querySelectorAll('input[name="platform"]').forEach(input => {
      input.addEventListener('change', this.updateSelectedPlatforms.bind(this));
    });

    // Format selection
    document.querySelectorAll('input[name="format"]').forEach(input => {
      input.addEventListener('change', this.updateSelectedFormats.bind(this));
    });

    // Brand analysis
    document.getElementById('analyzeBtn').addEventListener('click', this.analyzeBrand.bind(this));
    document.getElementById('importBtn').addEventListener('click', this.importBlogContent.bind(this));

    // Demographics
    document.getElementById('ageRange').addEventListener('change', this.updateDemographics.bind(this));
    document.getElementById('gender').addEventListener('change', this.updateDemographics.bind(this));
    document.getElementById('location').addEventListener('change', this.updateDemographics.bind(this));

    // Objective
    document.querySelectorAll('input[name="objective"]').forEach(input => {
      input.addEventListener('change', this.updateObjective.bind(this));
    });

    // Generate button
    document.getElementById('generateBtn').addEventListener('click', this.generateCreatives.bind(this));

    // Export and preview buttons
    document.getElementById('exportBtn').addEventListener('click', this.exportMediaKit.bind(this));
    document.getElementById('previewDemographics').addEventListener('click', this.showDemographicsPreview.bind(this));

    // Modal controls
    document.getElementById('modalClose').addEventListener('click', this.closeModal.bind(this));
    document.getElementById('demographicsClose').addEventListener('click', this.closeDemographicsModal.bind(this));
    document.getElementById('downloadSingle').addEventListener('click', this.downloadSingle.bind(this));
    
    document.getElementById('previewModal').addEventListener('click', (e) => {
      if (e.target.id === 'previewModal') this.closeModal();
    });
    
    document.getElementById('demographicsModal').addEventListener('click', (e) => {
      if (e.target.id === 'demographicsModal') this.closeDemographicsModal();
    });
  }

  initializeTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tabName = e.target.dataset.tab;
        
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        
        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
          content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');
      });
    });
  }

  initializeInterestTags() {
    document.querySelectorAll('.interest-tag').forEach(tag => {
      tag.addEventListener('click', (e) => {
        const interest = e.target.dataset.interest;
        e.target.classList.toggle('active');
        
        if (e.target.classList.contains('active')) {
          if (!this.demographics.interests.includes(interest)) {
            this.demographics.interests.push(interest);
          }
        } else {
          this.demographics.interests = this.demographics.interests.filter(i => i !== interest);
        }
      });
    });
  }

  handleDragOver(e) {
    e.preventDefault();
    e.currentTarget.style.borderColor = 'var(--primary-color)';
    e.currentTarget.style.background = 'rgba(0, 255, 255, 0.08)';
  }

  handleDrop(e) {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files[0] && files[0].type.startsWith('image/')) {
      this.processImageFile(files[0]);
    }
    e.currentTarget.style.borderColor = 'var(--border-color)';
    e.currentTarget.style.background = 'rgba(0, 255, 255, 0.03)';
  }

  handleImageSelect(e) {
    const file = e.target.files[0];
    if (file) {
      this.processImageFile(file);
    }
  }

  processImageFile(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      this.baseImage = {
        file: file,
        dataUrl: e.target.result,
        name: file.name
      };
      this.showImagePreview(e.target.result);
    };
    reader.readAsDataURL(file);
  }

  showImagePreview(dataUrl) {
    const uploadArea = document.getElementById('uploadArea');
    const imagePreview = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');
    
    uploadArea.style.display = 'none';
    imagePreview.style.display = 'block';
    previewImg.src = dataUrl;
  }

  removeImage() {
    this.baseImage = null;
    document.getElementById('uploadArea').style.display = 'block';
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('imageInput').value = '';
  }

  updateSelectedPlatforms() {
    this.selectedPlatforms = Array.from(document.querySelectorAll('input[name="platform"]:checked'))
      .map(input => input.value);
  }

  updateSelectedFormats() {
    this.selectedFormats = Array.from(document.querySelectorAll('input[name="format"]:checked'))
      .map(input => input.value);
  }

  updateDemographics() {
    this.demographics.age = document.getElementById('ageRange').value;
    this.demographics.gender = document.getElementById('gender').value;
    this.demographics.location = document.getElementById('location').value;
  }

  updateObjective() {
    this.objective = document.querySelector('input[name="objective"]:checked').value;
  }

  updateSelectedOptions() {
    // Update platform selections
    this.selectedPlatforms.forEach(platform => {
      const input = document.querySelector(`input[name="platform"][value="${platform}"]`);
      if (input) input.checked = true;
    });

    // Update format selections
    this.selectedFormats.forEach(format => {
      const input = document.querySelector(`input[name="format"][value="${format}"]`);
      if (input) input.checked = true;
    });
  }

  async analyzeBrand() {
    const url = document.getElementById('brandUrl').value;
    if (!url) return;

    const analyzeBtn = document.getElementById('analyzeBtn');
    const originalText = analyzeBtn.textContent;
    
    analyzeBtn.textContent = 'Analyzing...';
    analyzeBtn.disabled = true;

    // Simulate API call
    await this.delay(2000);

    // Mock brand analysis results
    const mockAnalysis = this.generateMockBrandAnalysis(url);
    this.brandData = mockAnalysis;
    
    this.displayBrandInsights(mockAnalysis);
    
    analyzeBtn.textContent = originalText;
    analyzeBtn.disabled = false;
  }

  async importBlogContent() {
    const platform = document.getElementById('platformSelect').value;
    const url = document.getElementById('blogUrl').value;
    
    if (!platform || !url) {
      alert('Please select a platform and enter a URL');
      return;
    }

    const importBtn = document.getElementById('importBtn');
    const originalText = importBtn.textContent;
    
    importBtn.textContent = 'Importing...';
    importBtn.disabled = true;

    // Simulate content import
    await this.delay(3000);

    // Mock blog content analysis
    const mockBlogData = this.generateMockBlogAnalysis(platform, url);
    this.blogData = mockBlogData;
    this.brandData = { ...this.brandData, ...mockBlogData };
    
    this.displayBrandInsights(this.brandData);
    
    importBtn.textContent = originalText;
    importBtn.disabled = false;
  }

  generateMockBrandAnalysis(url) {
    const tones = ['Professional', 'Playful', 'Minimalist', 'Bold', 'Elegant', 'Modern'];
    const styles = ['Corporate', 'Creative', 'Tech', 'Fashion', 'Lifestyle', 'Artistic'];
    const voices = ['Authoritative', 'Conversational', 'Inspirational', 'Educational', 'Humorous'];
    const colorPalettes = [
      ['#2196F3', '#FF5722', '#4CAF50'],
      ['#9C27B0', '#FF9800', '#00BCD4'],
      ['#F44336', '#3F51B5', '#FFEB3B'],
      ['#795548', '#607D8B', '#FF4081'],
      ['#009688', '#FFC107', '#E91E63']
    ];

    const randomTone = tones[Math.floor(Math.random() * tones.length)];
    const randomStyle = styles[Math.floor(Math.random() * styles.length)];
    const randomVoice = voices[Math.floor(Math.random() * voices.length)];
    const randomColors = colorPalettes[Math.floor(Math.random() * colorPalettes.length)];

    return {
      tone: randomTone,
      style: randomStyle,
      voice: randomVoice,
      colors: randomColors,
      url: url
    };
  }

  generateMockBlogAnalysis(platform, url) {
    const platformInsights = {
      medium: { tone: 'Thoughtful', voice: 'Educational', style: 'Editorial' },
      substack: { tone: 'Personal', voice: 'Conversational', style: 'Newsletter' },
      wordpress: { tone: 'Professional', voice: 'Authoritative', style: 'Blog' },
      linkedin: { tone: 'Business', voice: 'Professional', style: 'Corporate' },
      twitter: { tone: 'Casual', voice: 'Witty', style: 'Social' },
      custom: { tone: 'Unique', voice: 'Brand-specific', style: 'Custom' }
    };

    const insight = platformInsights[platform] || platformInsights.custom;
    
    return {
      ...insight,
      platform: platform,
      contentThemes: this.generateContentThemes(platform),
      audienceInsights: this.generateAudienceInsights(platform)
    };
  }

  generateContentThemes(platform) {
    const themes = {
      medium: ['Technology', 'Startups', 'Personal Growth', 'Design'],
      substack: ['Newsletter', 'Analysis', 'Commentary', 'Industry News'],
      wordpress: ['Blogging', 'Business', 'Lifestyle', 'How-to'],
      linkedin: ['Professional', 'Career', 'Industry', 'Leadership'],
      twitter: ['News', 'Opinions', 'Quick Tips', 'Engagement'],
      custom: ['Brand-specific', 'Unique Content', 'Custom Themes']
    };
    
    return themes[platform] || themes.custom;
  }

  generateAudienceInsights(platform) {
    const insights = {
      medium: 'Tech-savvy professionals and entrepreneurs',
      substack: 'Engaged subscribers interested in deep-dive content',
      wordpress: 'Diverse audience seeking informational content',
      linkedin: 'Business professionals and industry experts',
      twitter: 'Active social media users seeking quick updates',
      custom: 'Platform-specific audience characteristics'
    };
    
    return insights[platform] || insights.custom;
  }

  displayBrandInsights(analysis) {
    document.getElementById('brandTone').textContent = analysis.tone;
    document.getElementById('brandStyle').textContent = analysis.style;
    document.getElementById('brandColors').textContent = analysis.colors.join(', ');
    document.getElementById('brandVoice').textContent = analysis.voice;
    document.getElementById('brandInsights').style.display = 'block';
  }

  showDemographicsPreview() {
    const summary = document.getElementById('targetingSummary');
    const interests = this.demographics.interests.length > 0 ? this.demographics.interests.join(', ') : 'None selected';
    
    summary.innerHTML = `
      <div class="targeting-item">
        <strong>Age Range:</strong> ${this.demographics.age}
      </div>
      <div class="targeting-item">
        <strong>Gender:</strong> ${this.demographics.gender}
      </div>
      <div class="targeting-item">
        <strong>Location:</strong> ${this.demographics.location}
      </div>
      <div class="targeting-item">
        <strong>Interests:</strong> ${interests}
      </div>
      <div class="targeting-item">
        <strong>Campaign Objective:</strong> ${this.objective}
      </div>
      <div class="targeting-item">
        <strong>Estimated Reach:</strong> ${this.calculateEstimatedReach()}
      </div>
    `;
    
    document.getElementById('demographicsModal').style.display = 'flex';
  }

  calculateEstimatedReach() {
    // Mock calculation based on demographics
    const baseReach = 1000000;
    let multiplier = 1;
    
    // Age adjustments
    if (this.demographics.age === '18-24') multiplier *= 0.8;
    if (this.demographics.age === '55+') multiplier *= 0.6;
    
    // Gender adjustments
    if (this.demographics.gender !== 'all') multiplier *= 0.5;
    
    // Interest adjustments
    multiplier *= Math.max(0.3, 1 - (this.demographics.interests.length * 0.1));
    
    // Location adjustments
    if (this.demographics.location !== 'global') multiplier *= 0.4;
    
    const reach = Math.floor(baseReach * multiplier);
    return reach.toLocaleString() + ' people';
  }

  async generateCreatives() {
    if (!this.baseImage) {
      alert('Please upload a base image first.');
      return;
    }

    if (this.selectedPlatforms.length === 0 || this.selectedFormats.length === 0) {
      alert('Please select at least one platform and format.');
      return;
    }

    this.showLoadingOverlay();
    
    const loadingTexts = [
      'Processing your image...',
      'Analyzing brand guidelines...',
      'Processing blog content...',
      'Analyzing target demographics...',
      'Generating creative variants...',
      'Optimizing for platforms...',
      'Applying demographic targeting...',
      'Finalizing creatives...'
    ];

    // Simulate processing steps
    for (let i = 0; i < loadingTexts.length; i++) {
      document.getElementById('loadingText').textContent = loadingTexts[i];
      await this.delay(800);
    }

    // Generate mock creatives
    this.generatedCreatives = this.createMockCreatives();
    
    this.hideLoadingOverlay();
    this.displayResults();
  }

  createMockCreatives() {
    const creatives = [];
    const variants = ['A', 'B', 'C'];
    
    this.selectedPlatforms.forEach(platform => {
      this.selectedFormats.forEach(format => {
        variants.forEach((variant, index) => {
          creatives.push({
            id: `${platform}-${format}-${variant}`,
            platform: platform,
            format: format,
            variant: variant,
            title: `${this.formatName(platform)} ${this.formatName(format)} - Variant ${variant}`,
            image: this.generateMockCreativeImage(platform, format, variant, index),
            dimensions: this.getFormatDimensions(format),
            optimizedFor: this.getOptimizationFeatures(platform, format),
            targetDemographics: this.getTargetingSummary(),
            objective: this.objective,
            estimatedReach: this.calculateEstimatedReach()
          });
        });
      });
    });

    return creatives;
  }

  getTargetingSummary() {
    const interests = this.demographics.interests.length > 0 ? this.demographics.interests.join(', ') : 'General';
    return `${this.demographics.age}, ${this.demographics.gender}, ${interests}`;
  }

  formatName(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  getFormatDimensions(format) {
    const dimensions = {
      post: '1080x1080',
      story: '1080x1920',
      banner: '1920x1080',
      reel: '1080x1920'
    };
    return dimensions[format] || '1080x1080';
  }

  getOptimizationFeatures(platform, format) {
    const features = {
      facebook: ['News Feed', 'Stories', 'Marketplace'],
      instagram: ['Feed', 'Stories', 'Reels', 'IGTV'],
      tiktok: ['For You Page', 'Stories', 'Live']
    };
    return features[platform] || [];
  }

  generateMockCreativeImage(platform, format, variant, index) {
    // Create a canvas to generate a mock creative
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // Set dimensions based on format
    const dimensions = {
      post: [400, 400],
      story: [400, 711],
      banner: [400, 225],
      reel: [400, 711]
    };
    
    const [width, height] = dimensions[format] || [400, 400];
    canvas.width = width;
    canvas.height = height;

    // Create gradient background based on platform and demographics
    const gradients = {
      facebook: ['#1877f2', '#42a5f5'],
      instagram: ['#e4405f', '#f77737'],
      tiktok: ['#000000', '#ff0050']
    };

    const [color1, color2] = gradients[platform] || ['#00ffff', '#0066ff'];
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, color1);
    gradient.addColorStop(1, color2);
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Add demographic-influenced overlay
    const ageOpacity = this.demographics.age === '18-24' ? 0.2 : 0.1;
    ctx.fillStyle = `rgba(255, 255, 255, ${ageOpacity + index * 0.05})`;
    ctx.fillRect(0, 0, width, height);

    // Add variant and targeting info
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`Variant ${variant}`, width / 2, height / 2 - 30);
    
    ctx.font = '14px Arial';
    ctx.fillText(this.formatName(platform), width / 2, height / 2);
    ctx.fillText(`${format.toUpperCase()}`, width / 2, height / 2 + 20);
    ctx.fillText(`${this.demographics.age}`, width / 2, height / 2 + 40);

    // Add interest-based visual elements
    if (this.demographics.interests.includes('tech')) {
      ctx.strokeStyle = '#00ffff';
      ctx.lineWidth = 2;
      ctx.strokeRect(20, 20, width - 40, height - 40);
    }

    return canvas.toDataURL();
  }

  displayResults() {
    const resultsSection = document.getElementById('resultsSection');
    const creativeGrid = document.getElementById('creativeGrid');
    const resultsCount = document.getElementById('resultsCount');

    resultsCount.textContent = `${this.generatedCreatives.length} variants`;
    creativeGrid.innerHTML = '';

    this.generatedCreatives.forEach(creative => {
      const creativeCard = this.createCreativeCard(creative);
      creativeGrid.appendChild(creativeCard);
    });

    resultsSection.style.display = 'block';
    resultsSection.scrollIntoView({ behavior: 'smooth' });
  }

  createCreativeCard(creative) {
    const card = document.createElement('div');
    card.className = 'creative-card';
    card.addEventListener('click', () => this.openPreviewModal(creative));

    card.innerHTML = `
      <div class="creative-preview">
        <img src="${creative.image}" alt="${creative.title}">
        <div class="creative-overlay"></div>
      </div>
      <div class="creative-info">
        <div class="creative-title">${creative.title}</div>
        <div class="creative-meta">
          <span>${creative.dimensions}</span>
          <span class="creative-variant">Variant ${creative.variant}</span>
        </div>
        <div class="creative-targeting">
          <span class="targeting-tag">${creative.targetDemographics}</span>
        </div>
      </div>
    `;

    return card;
  }

  openPreviewModal(creative) {
    document.getElementById('modalImage').src = creative.image;
    document.getElementById('modalTitle').textContent = creative.title;
    document.getElementById('modalPlatform').textContent = this.formatName(creative.platform);
    document.getElementById('modalFormat').textContent = `${this.formatName(creative.format)} (${creative.dimensions})`;
    document.getElementById('modalVariant').textContent = creative.variant;
    document.getElementById('modalTarget').textContent = creative.targetDemographics;
    
    document.getElementById('previewModal').style.display = 'flex';
    document.getElementById('downloadSingle').dataset.creativeId = creative.id;
  }

  closeModal() {
    document.getElementById('previewModal').style.display = 'none';
  }

  closeDemographicsModal() {
    document.getElementById('demographicsModal').style.display = 'none';
  }

  downloadSingle() {
    const creativeId = document.getElementById('downloadSingle').dataset.creativeId;
    const creative = this.generatedCreatives.find(c => c.id === creativeId);
    
    if (creative) {
      this.downloadImage(creative.image, `${creative.title}.png`);
      this.closeModal();
    }
  }

  exportMediaKit() {
    if (this.generatedCreatives.length === 0) {
      alert('No creatives to export. Please generate creatives first.');
      return;
    }

    // Create enhanced media kit with demographics
    const mediaKit = {
      metadata: {
        generatedAt: new Date().toISOString(),
        totalCreatives: this.generatedCreatives.length,
        platforms: this.selectedPlatforms,
        formats: this.selectedFormats,
        brandData: this.brandData,
        blogData: this.blogData,
        demographics: this.demographics,
        objective: this.objective,
        estimatedReach: this.calculateEstimatedReach()
      },
      creatives: this.generatedCreatives
    };

    // Download each creative
    this.generatedCreatives.forEach((creative, index) => {
      setTimeout(() => {
        this.downloadImage(creative.image, `reflexion-${creative.id}.png`);
      }, index * 200);
    });

    // Download enhanced metadata
    setTimeout(() => {
      this.downloadJSON(mediaKit.metadata, 'media-kit-metadata.json');
    }, this.generatedCreatives.length * 200);

    alert(`Exporting ${this.generatedCreatives.length} targeted creatives and metadata...`);
  }

  downloadImage(dataUrl, filename) {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  downloadJSON(data, filename) {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  }

  showLoadingOverlay() {
    document.getElementById('loadingOverlay').style.display = 'flex';
  }

  hideLoadingOverlay() {
    document.getElementById('loadingOverlay').style.display = 'none';
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
  new ReflexionApp();
});